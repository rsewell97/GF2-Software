# GF2-Software
## CUED IIA project - Logic simulator

### Getting Started

Run the following sequence of commands in your terminal
```
git clone https://github.com/rsewell97/GF2-Software.git
cd GF2-Software/
pip3 install -r requirements.txt
```
Then for Linux and MacOSX:
```
./main_project/main.py
```
Or for Windows:
```
python3 main_project.py
```
And you will see the graphical user interface of the logic simulator
